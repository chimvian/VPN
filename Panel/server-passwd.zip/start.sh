#!/bin/bash

while true
do
	bash /etc/openvpn/dhl.sh
	echo "$(date +%Y-%m-%d~%H:%M:%S)实时监控运行正常" >>/etc/openvpn/dhl.log
	sleep 30  #实时监控时间，推荐30s~60s
	bash /etc/openvpn/dhl2.sh
	echo "$(date +%Y-%m-%d~%H:%M:%S)实时监控运行正常" >>/etc/openvpn/dhl2.log
	sleep 30  #实时监控时间，推荐30s~60s
	bash /etc/openvpn/dhl3.sh
	echo "$(date +%Y-%m-%d~%H:%M:%S)实时监控运行正常" >>/etc/openvpn/dhl3.log
	sleep 30  #实时监控时间，推荐30s~60s
done
