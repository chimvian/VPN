#!/bin/bash

while true
do
	bash /etc/openvpn/dhl.sh
	echo "$(date +%Y-%m-%d~%H:%M:%S)实时监控运行正常" >>/etc/openvpn/dhl.log
	sleep 60  #实时监控时间，推荐30s~60s
done
