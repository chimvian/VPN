#!/bin/sh

DBHOST='localhost'
DBNAME='ov'
DBADMIN='root'
DBPASSWD='MySQLPass'

user=$username
rp=$password
Ban=';|UNION|Select|Update|SET|Insert|INTO|VALUES|Delete|FROM|Create|Alter|Drop|TRUNCATE|TABLE|DATABASE|script|EXEC'
if [ `echo ${username} | sed s/[[:space:]]//g | grep -i -E "${Ban}"` ]
then
exit 1
else
if [ `echo ${password} | sed s/[[:space:]]//g | grep -i -E "${Ban}"` ]
then
exit 1
else
mysql -h$DBHOST -u$DBADMIN -p$DBPASSWD -e "SELECT pass FROM openvpn WHERE iuser='$user';" $DBNAME>>log.txt
mysql -h$DBHOST -u$DBADMIN -p$DBPASSWD -e "SELECT irecv FROM openvpn WHERE iuser='$user';" $DBNAME>>log.txt
mysql -h$DBHOST -u$DBADMIN -p$DBPASSWD -e "SELECT isent FROM openvpn WHERE iuser='$user';" $DBNAME>>log.txt
mysql -h$DBHOST -u$DBADMIN -p$DBPASSWD -e "SELECT maxll FROM openvpn WHERE iuser='$user';" $DBNAME>>log.txt
mysql -h$DBHOST -u$DBADMIN -p$DBPASSWD -e "SELECT i FROM openvpn WHERE iuser='$user';" $DBNAME>>log.txt
mysql -h$DBHOST -u$DBADMIN -p$DBPASSWD -e "SELECT endtime FROM openvpn WHERE iuser='$user';" $DBNAME>>log.txt
pass=$(sed -n 2p log.txt)
recv=$(sed -n 4p log.txt)
sent=$(sed -n 6p log.txt)
all=$(sed -n 8p log.txt)
i=$(sed -n 10p log.txt)
time=$(sed -n 12p log.txt)
now=$(date -d $(date +%Y-%m-%d) +%s)
rm -rf log.txt
if [ "$rp" == "$pass" ] && [ "$i" == "1" ] && [ "$[$recv+$sent]" -lt "$all" ] && [ "$time" -ge "$now" ];
then
mysql -h$DBHOST -u$DBADMIN -p$DBPASSWD -e "UPDATE openvpn SET status=1 WHERE iuser='$user';" $DBNAME
exit 0
else
echo $(date +%Y年%m月%d日%k时%M分) "用户登录失败" "账号:"${username} "密码:"${password}>>user_error.log
exit 1
fi
#
fi
fi